import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-blocked-users',
  templateUrl: './admin-blocked-users.component.html',
  styleUrls: ['./admin-blocked-users.component.scss']
})
export class AdminBlockedUsersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
