import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-regitser',
  templateUrl: './regitser.component.html',
  styleUrls: ['./regitser.component.scss']
})
export class RegitserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
