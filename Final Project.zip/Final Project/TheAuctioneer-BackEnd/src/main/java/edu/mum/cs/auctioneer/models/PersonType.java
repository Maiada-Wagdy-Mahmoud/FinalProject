package edu.mum.cs.auctioneer.models;

public enum PersonType {

	user,admin
}
