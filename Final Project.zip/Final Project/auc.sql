-- MySQL dump 10.13  Distrib 5.7.27, for Linux (x86_64)
--
-- Host: localhost    Database: testsch
-- ------------------------------------------------------
-- Server version	5.7.27-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_type`
--

DROP TABLE IF EXISTS `account_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_type` (
  `account_type_id` int(11) NOT NULL,
  `account_type_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`account_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_type`
--

LOCK TABLES `account_type` WRITE;
/*!40000 ALTER TABLE `account_type` DISABLE KEYS */;
INSERT INTO `account_type` VALUES (1,'savings'),(2,'checking'),(3,'loan');
/*!40000 ALTER TABLE `account_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `account_id` bigint(20) NOT NULL,
  `account_number` bigint(20) DEFAULT NULL,
  `balance` double DEFAULT NULL,
  `account_type_id` int(11) DEFAULT NULL,
  `customer_id` bigint(20) DEFAULT NULL,
  `accountnumber` bigint(20) NOT NULL,
  PRIMARY KEY (`account_id`),
  KEY `FKt0unjbb1cct10si7nymsbut42` (`account_type_id`),
  KEY `FKn6x8pdp50os8bq5rbb792upse` (`customer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (18,NULL,180,1,14,123),(19,NULL,200,2,14,1234),(20,NULL,120,3,14,12345);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounttypes`
--

DROP TABLE IF EXISTS `accounttypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounttypes` (
  `accounttypeid` int(11) NOT NULL AUTO_INCREMENT,
  `accounttypename` varchar(255) NOT NULL,
  PRIMARY KEY (`accounttypeid`),
  UNIQUE KEY `UK_9i7ohhs5194t86ftsdwp6f1ml` (`accounttypename`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounttypes`
--

LOCK TABLES `accounttypes` WRITE;
/*!40000 ALTER TABLE `accounttypes` DISABLE KEYS */;
INSERT INTO `accounttypes` VALUES (1,'checking'),(2,'savings'),(3,'loan');
/*!40000 ALTER TABLE `accounttypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (11);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bidding`
--

DROP TABLE IF EXISTS `bidding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bidding` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `bid_date` date DEFAULT NULL,
  `price` double DEFAULT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `modified` date DEFAULT NULL,
  `created` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKajythakayr8dko63k16f6myos` (`post_id`),
  KEY `FKeyp19ckyartk0hcox1hn7gu6s` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bidding`
--

LOCK TABLES `bidding` WRITE;
/*!40000 ALTER TABLE `bidding` DISABLE KEYS */;
INSERT INTO `bidding` VALUES (1,'2019-10-22',20,1,2,NULL,'2019-10-22'),(2,'2019-10-22',30,1,3,NULL,'2019-10-22'),(3,'2019-10-21',40,1,1,NULL,'2019-10-22'),(4,'2019-10-22',50,1,1,NULL,'2019-10-22'),(5,'2019-10-22',60,1,1,NULL,'2019-10-22'),(6,NULL,70,1,1,NULL,'2019-10-23'),(7,NULL,80,1,1,NULL,'2019-10-23'),(8,NULL,90,1,1,NULL,'2019-10-23'),(9,NULL,100,1,1,NULL,'2019-10-23'),(10,NULL,110,1,1,NULL,'2019-10-23'),(11,NULL,120,1,1,NULL,'2019-10-23'),(12,NULL,130,1,1,NULL,'2019-10-23'),(13,NULL,140,1,1,NULL,'2019-10-23'),(14,NULL,150,1,1,NULL,'2019-10-23'),(15,NULL,160,1,1,NULL,'2019-10-23'),(16,NULL,170,1,1,NULL,'2019-10-23'),(17,NULL,180,1,1,NULL,'2019-10-23'),(18,NULL,190,1,1,NULL,'2019-10-23'),(19,NULL,200,1,1,NULL,'2019-10-23'),(20,NULL,210,1,1,NULL,'2019-10-23'),(21,NULL,220,1,1,NULL,'2019-10-23'),(22,NULL,230,1,1,NULL,'2019-10-23'),(23,NULL,240,1,1,NULL,'2019-10-24'),(24,NULL,250,1,1,NULL,'2019-10-24'),(25,NULL,260,1,1,NULL,'2019-10-24'),(26,NULL,270,1,1,NULL,'2019-10-24'),(27,NULL,110,3,1,NULL,'2019-10-24'),(28,NULL,201000,6,1,NULL,'2019-10-24');
/*!40000 ALTER TABLE `bidding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `books` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_published` date DEFAULT NULL,
  `isbn` varchar(255) NOT NULL,
  `overdue_fee` double DEFAULT NULL,
  `publisher` varchar(255) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`book_id`),
  UNIQUE KEY `UK_kibbepcitr0a3cpk3rfr7nihn` (`isbn`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (1,'2019-10-10','015403',5.1,'Mostafa','book title'),(2,'2019-10-02','0154031',5.1,'Mostafa','ddd');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `modified` date DEFAULT NULL,
  `created` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'HOUSE',NULL,NULL),(2,'Car',NULL,NULL),(3,'Electronics',NULL,NULL),(4,'Clothes',NULL,NULL),(5,'Entertainment',NULL,NULL);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classroom`
--

DROP TABLE IF EXISTS `classroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classroom` (
  `classroom_id` bigint(20) NOT NULL,
  `building_name` varchar(255) DEFAULT NULL,
  `room_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`classroom_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classroom`
--

LOCK TABLES `classroom` WRITE;
/*!40000 ALTER TABLE `classroom` DISABLE KEYS */;
INSERT INTO `classroom` VALUES (3,'140','206');
/*!40000 ALTER TABLE `classroom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `customer_id` bigint(20) NOT NULL,
  `contact_phone_number` varchar(255) DEFAULT NULL,
  `customer_number` bigint(20) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `email_address` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `customernumber` bigint(20) NOT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `UK_35aybwt79d3rkvhffo6hi43qu` (`customernumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (14,'01206165555',123,'2019-10-01','m@gmail.com','Mostafa','Anwar','Mahmoud',0);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hibernate_sequence`
--

DROP TABLE IF EXISTS `hibernate_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hibernate_sequence`
--

LOCK TABLES `hibernate_sequence` WRITE;
/*!40000 ALTER TABLE `hibernate_sequence` DISABLE KEYS */;
INSERT INTO `hibernate_sequence` VALUES (21);
/*!40000 ALTER TABLE `hibernate_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `phonr` varchar(255) DEFAULT NULL,
  `role` int(11) DEFAULT NULL,
  `modified` date DEFAULT NULL,
  `created` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES (1,NULL,'mostafa@gmail.com','Mostafa','123456','01206165858',0,NULL,'2019-10-15'),(2,NULL,'ahmed@gmail.com','Ahmed','123456','01206165858',0,NULL,'2019-10-16'),(3,NULL,'maiada@gmail.com','Maiada','123456','01206165858',0,NULL,'2019-10-16'),(11,NULL,'admin@gmail.com','admin','123456','01456456548',1,NULL,NULL),(4,NULL,'mahmoud@gmail.com','Mahmoud','123456','01206165858',0,NULL,NULL),(5,NULL,'gaber@gmail.com','Gaber','123456','01206165858',0,NULL,NULL),(6,NULL,'ehab@gmail.com','Ehab','123456','01206165858',0,NULL,NULL),(7,NULL,'taha@gmail.com','Taha','123456','01206165858',0,NULL,NULL),(8,NULL,'Dalia@gmail.com','Dalia','123456','01206165858',0,NULL,NULL),(9,NULL,'Aya@gmail.com','Aya','123456','01206165858',0,NULL,NULL),(10,NULL,'John@gmail.com','John','123456','01206165858',0,NULL,NULL);
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photo`
--

DROP TABLE IF EXISTS `photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `photo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  `modified` date DEFAULT NULL,
  `created` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKt47fmi9mi5p9dkjyyuoyfc63f` (`post_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photo`
--

LOCK TABLES `photo` WRITE;
/*!40000 ALTER TABLE `photo` DISABLE KEYS */;
INSERT INTO `photo` VALUES (3,'/var/www/html/auctioneer/1-1571928372495/bradybunchhouse_sc11.jpg',4,NULL,'2019-10-24'),(4,'/var/www/html/auctioneer/1-1571928422030/B3-DM067_RIGHTS_IM_20190319162958.jpg',5,NULL,'2019-10-24'),(5,'/var/www/html/auctioneer/1-1571928475005/download.jpeg',6,NULL,'2019-10-24'),(6,'/var/www/html/auctioneer/1-1571929053882/pexels-photo-210019.jpeg',7,NULL,'2019-10-24'),(7,'/var/www/html/auctioneer/1-1571929102293/pexels-photo-112460.jpeg',8,NULL,'2019-10-24'),(8,'/var/www/html/auctioneer/1-1571929136346/911-road-3629a.jpg',9,NULL,'2019-10-24'),(9,'/var/www/html/auctioneer/1-1571929174886/pexels-photo-241316.jpeg',10,NULL,'2019-10-24'),(10,'/var/www/html/auctioneer/1-1571929212433/performance.jpg',11,NULL,'2019-10-24'),(11,'/var/www/html/auctioneer/2-1571929409360/VB201705171774173-ak_LWBP1035915391-1514455318.jpeg',12,NULL,'2019-10-24'),(12,'/var/www/html/auctioneer/2-1571929442876/15468-93-1.jpg',13,NULL,'2019-10-24'),(13,'/var/www/html/auctioneer/2-1571929484847/images.jpeg',14,NULL,'2019-10-24'),(14,'/var/www/html/auctioneer/2-1571929514573/galaxynote10plus-300x225.jpg',15,NULL,'2019-10-24'),(15,'/var/www/html/auctioneer/2-1571929638822/download (1).jpeg',16,NULL,'2019-10-24'),(16,'/var/www/html/auctioneer/2-1571929672262/download (2).jpeg',17,NULL,'2019-10-24'),(17,'/var/www/html/auctioneer/2-1571929701794/camel-1563997933.jpg',18,NULL,'2019-10-24'),(18,'/var/www/html/auctioneer/2-1571929734044/71sM2Vs9ZuL._UX522_.jpg',19,NULL,'2019-10-24'),(19,'/var/www/html/auctioneer/2-1571929757336/1863791_363_f.jpeg',20,NULL,'2019-10-24'),(20,'/var/www/html/auctioneer/3-1571929869143/download (3).jpeg',21,NULL,'2019-10-24'),(21,'/var/www/html/auctioneer/3-1571929907115/hqdefault.jpg',22,NULL,'2019-10-24'),(22,'/var/www/html/auctioneer/1-1571934674178/bradybunchhouse_sc11.jpg',23,NULL,'2019-10-24');
/*!40000 ALTER TABLE `photo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `city` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `expirdate` date DEFAULT NULL,
  `incrvalue` int(11) DEFAULT NULL,
  `minprice` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `modified` date DEFAULT NULL,
  `created` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKg6l1ydp1pwkmyj166teiuov1b` (`category_id`),
  KEY `FK72mt33dhhs48hf9gcqrq4fxte` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (4,'3','2','nice house','2019-02-02',1000,1500000,'nice house',1,1,NULL,'2019-10-24'),(5,'2','2','nice house','2019-02-02',1000,200000,'nice house',1,1,NULL,'2019-10-24'),(6,'3','2','nice house','2019-02-01',1000,201000,'nice house',1,1,'2019-10-24','2019-10-24'),(7,'2','1','nice car','2019-02-02',1000,265400,'nice car',2,1,NULL,'2019-10-24'),(8,'2','2','nice car','2019-02-01',1200,300500,'car',2,1,'2019-10-24',NULL),(9,'2','3','nice car','2019-02-02',2000,215120,'nice car',2,1,NULL,'2019-10-24'),(10,'2','1','nice car','2019-02-02',120,135000,'nice car',2,1,NULL,'2019-10-24'),(11,'1','2','nice car','2019-02-02',1000,132000,'nice car',2,1,NULL,'2019-10-24'),(12,'2','3','new device','2019-02-02',500,1200,'new device',3,2,NULL,'2019-10-24'),(13,'2','1','new device','2019-02-02',100,1200,'new device',3,2,NULL,'2019-10-24'),(14,'2','1','new device','2019-02-02',100,1200,'new device',3,2,NULL,'2019-10-24'),(15,'2','2','new device','2019-02-02',100,1500,'new device',2,2,NULL,'2019-10-24'),(16,'1','2','new coat','2019-02-02',6,150,'new coat',4,2,NULL,'2019-10-24'),(17,'1','3','new coat','2019-02-02',20,142,'new coat',4,2,NULL,'2019-10-24'),(18,'1','2','new coat','2019-02-02',10,200,'new coat',4,2,NULL,'2019-10-24'),(19,'1','3','new coat','2019-02-02',5,130,'new coat',4,2,NULL,'2019-10-24'),(20,'2','1','new coat','2019-02-02',6,130,'new coat',4,2,NULL,'2019-10-24'),(21,'2','2','new game','2019-02-02',1,20,'new game',5,3,NULL,'2019-10-24'),(22,'1','2','new game','2019-02-02',1,20,'new game',5,3,NULL,'2019-10-24'),(23,'','','house','2019-10-25',100,10000,'house',1,1,NULL,'2019-10-24');
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `prduct_id` bigint(20) NOT NULL,
  `date_supplied` datetime DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `quantity_in_stock` int(11) DEFAULT NULL,
  `unit_price` double DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `product_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`prduct_id`),
  KEY `FK6i174ixi9087gcvvut45em7fd` (`supplier_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (13,'2019-10-01 00:00:00','T-shirt',5,10,12,1234);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `report_date` date DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `reported_id` bigint(20) DEFAULT NULL,
  `reporter_id` bigint(20) DEFAULT NULL,
  `modified` date DEFAULT NULL,
  `created` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKkqwu7egf4fup0xog0ot2s065c` (`reported_id`),
  KEY `FKndpjl61ubcm2tkf7ml1ynq13t` (`reporter_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report`
--

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
INSERT INTO `report` VALUES (11,'2019-10-17','new report',2,5,NULL,NULL),(12,NULL,'Bad user',1,1,NULL,'2019-10-24');
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `student_id` bigint(20) NOT NULL,
  `cgpa` double DEFAULT NULL,
  `date_of_enrollment` datetime DEFAULT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `student_number` varchar(255) NOT NULL,
  `classroom_id` bigint(20) DEFAULT NULL,
  `transcript_id` bigint(20) DEFAULT NULL,
  `international` bit(1) NOT NULL,
  `midlle_name` varchar(255) DEFAULT NULL,
  `enrollment_date` date DEFAULT NULL,
  PRIMARY KEY (`student_id`),
  KEY `FK1rs4md9whkjqy20v181d18kfy` (`classroom_id`),
  KEY `FKp1xt5it0q3frsaxwondgh6mh5` (`transcript_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (2,3.45,'2019-05-24 05:00:00','Anna','Smith','Lynn','000-61-0001',NULL,NULL,_binary '\0',NULL,NULL),(5,3.45,'2019-05-24 05:00:00','Anna','Smith','Lynn','000-61-0001',3,4,_binary '\0',NULL,NULL),(6,3,NULL,'Mostafa Mahmoud Anwar ','Zaid',NULL,'12025 - 120',NULL,NULL,_binary '\0','mm','2019-10-14'),(7,3.98,NULL,'Mostafa Mahmoud Anwar ','Zaid',NULL,'12025 - 120',NULL,NULL,_binary '\0','mm','2019-10-14'),(8,3.98,NULL,'Mostafa Mahmoud Anwar ','Zaid',NULL,'12025 - 120',NULL,NULL,_binary '\0','mm','2019-10-14'),(9,3.95,NULL,'Mostafa Mahmoud Anwar ','Zaid',NULL,'12025 - 120',NULL,NULL,_binary '\0','mm','2019-10-14'),(10,3.98,NULL,'Mostafa Mahmoud Anwar ','Zaid',NULL,'12025 - 120',NULL,NULL,_binary '\0','mm','2019-10-14'),(11,3.6,NULL,'new student','stu',NULL,'12025 - 120',NULL,NULL,_binary '','mm','2019-10-10');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `supplier_id` int(11) NOT NULL,
  `contact_phone_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `supplier_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (12,'01206165555','Calvin Klien',123);
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transcript`
--

DROP TABLE IF EXISTS `transcript`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transcript` (
  `transcript_id` bigint(20) NOT NULL,
  `degree_title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`transcript_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transcript`
--

LOCK TABLES `transcript` WRITE;
/*!40000 ALTER TABLE `transcript` DISABLE KEYS */;
INSERT INTO `transcript` VALUES (4,'Master');
/*!40000 ALTER TABLE `transcript` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `blocked` bit(1) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (_binary '\0',10),(_binary '\0',2),(_binary '\0',3),(_binary '\0',4),(_binary '\0',5),(_binary '\0',6),(_binary '\0',7),(_binary '\0',8),(_binary '\0',9),(_binary '\0',1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_entity`
--

DROP TABLE IF EXISTS `user_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_entity` (
  `id` bigint(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_entity`
--

LOCK TABLES `user_entity` WRITE;
/*!40000 ALTER TABLE `user_entity` DISABLE KEYS */;
INSERT INTO `user_entity` VALUES (1,'mostafa@gmail.com','Mostafa');
/*!40000 ALTER TABLE `user_entity` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-24 16:38:56
